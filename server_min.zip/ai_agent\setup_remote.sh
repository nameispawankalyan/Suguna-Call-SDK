#!/bin/bash

# Update System
sudo apt update && sudo apt upgrade -y
sudo apt install python3-pip python3-venv screen -y

# Create Directory
mkdir -p ~/ai-agent
cd ~/ai-agent

# Create Virtual Environment
python3 -m venv venv
source venv/bin/activate

# Install Dependencies
pip install --upgrade pip
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt
else
    pip install livekit-agents livekit-server-sdk python-dotenv openai deepgram-sdk httpx
fi

# Create .env file with provided values
cat <<EOF > .env
DEEPGRAM_API_KEY=6781a45d425dbc775542c206fd77591d1422716a
OPENAI_API_KEY=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
LIVEKIT_WS_URL=wss://friendzone-ucdl197v.livekit.cloud
LIVEKIT_URL=wss://friendzone-ucdl197v.livekit.cloud
LIVEKIT_API_KEY=APIvzZ3bPvaBfmZ
LIVEKIT_API_SECRET=TLszKRlKFtewipSHQxjgABmYG27HMFT4i23nutLRSBE
EOF

echo "✅ Environment Setup Complete!"
echo "To run the agent manually: source venv/bin/activate && python agent.py"
echo "To run in background: screen -S agent python agent.py"
